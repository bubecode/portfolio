<!-- End Page Content -->
            </div> 
            
            <footer class="text-center py-3 text-muted small border-top bg-white">
                &copy; <?php echo date('Y'); ?> Portfolio Admin Panel.
            </footer>
        </div> <!-- End Content Wrapper -->
    </div> <!-- End App Wrapper -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
