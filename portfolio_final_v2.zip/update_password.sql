UPDATE `users` 
SET `password_hash` = '$2y$10$FOmpMoNaGFy/IqJppINLW.EH8xWfAi0VAl3HvQEdFlsVxTzSc3pg6' 
WHERE `email` = 'admin@example.com';
